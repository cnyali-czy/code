#include <bits/stdc++.h>

#define x first
#define y second
#define mp make_pair
#define pb push_back
#define Set(i, v) memset(i, v, sizeof i)
#define For(i, j, k) for (int i = j; i <= k; i++)
#define Forr(i, j, k) for (int i = j; i >= k; i--)

#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

template<class T> bool chkmax(T &x, T y) { return x > y ? false : (x = y, true); }
template<class T> bool chkmin(T &x, T y) { return x < y ? false : (x = y, true); }

int main(){

	return 0;
}
